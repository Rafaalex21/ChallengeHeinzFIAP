CREATE TABLE t_certificado (
id_certificado VARCHAR2(10) NOT NULL,
id_fornecedor VARCHAR2(10) NOT NULL,
nm_certificado VARCHAR2(50) NOT NULL,
org_emissor VARCHAR2(50) NOT NULL,
nr_autenticacao VARCHAR2(50) NOT NULL,
dt_emissao DATE NOT NULL,
dt_validade DATE
);
ALTER TABLE t_certificado ADD CONSTRAINT t_certificado_pk PRIMARY KEY ( id_certificado );
CREATE TABLE t_emp_objetivo (
id_objetivo VARCHAR2(10) NOT NULL,
id_empresa VARCHAR2(10) NOT NULL
);
ALTER TABLE t_emp_objetivo ADD CONSTRAINT t_emp_objetivo_pk PRIMARY KEY ( id_objetivo,
id_empresa );
CREATE TABLE t_empresa (
id_empresa VARCHAR2(10) NOT NULL,
id_localizacao VARCHAR2(10) NOT NULL,
nm_empresa VARCHAR2(50) NOT NULL
);
CREATE UNIQUE INDEX t_empresa__idx ON
t_empresa (
id_localizacao
ASC );
ALTER TABLE t_empresa ADD CONSTRAINT t_empresa_pk PRIMARY KEY ( id_empresa ); CREATE TABLE t_fator_conver (
id_fator VARCHAR2(10) NOT NULL,
id_media VARCHAR2(10) NOT NULL,
fator_conver NUMBER(5, 5) NOT NULL,
ds_unid_orig VARCHAR2(30) NOT NULL,
ds_unid_dest VARCHAR2(30) NOT NULL
);
ALTER TABLE t_fator_conver ADD CONSTRAINT t_fator_conver_pk PRIMARY KEY ( id_fator );
CREATE TABLE t_fornecedor (
id_fornecedor VARCHAR2(10) NOT NULL,
id_localizacao VARCHAR2(10) NOT NULL,
nm_fornecedor VARCHAR2(50) NOT NULL
);
CREATE UNIQUE INDEX t_fornecedor__idx ON
t_fornecedor (
id_localizacao
ASC );
ALTER TABLE t_fornecedor ADD CONSTRAINT t_fornecedor_pk PRIMARY KEY ( id_fornecedor );
CREATE TABLE t_fornecimento (
id_fornecedor VARCHAR2(10) NOT NULL,
id_insumo VARCHAR2(10) NOT NULL
);
ALTER TABLE t_fornecimento ADD CONSTRAINT t_fornecimento_pk PRIMARY KEY ( id_fornecedor,
id_insumo );
CREATE TABLE t_insumos (
id_insumo VARCHAR2(10) NOT NULL,
id_tipo VARCHAR2(10) NOT NULL,
id_media VARCHAR2(10) NOT NULL,
id_requisicao VARCHAR2(10),
nm_insumo VARCHAR2(50) NOT NULL,
vr_unitario NUMBER(10, 5) NOT NULL
);
CREATE UNIQUE INDEX t_insumos__idx ON
t_insumos (
id_tipo
ASC );
CREATE UNIQUE INDEX t_insumos__idxv1 ON
t_insumos (
id_media
ASC );
ALTER TABLE t_insumos ADD CONSTRAINT t_insumos_pk PRIMARY KEY ( id_insumo );
CREATE TABLE t_localizacao (
id_localizacao VARCHAR2(10) NOT NULL,
ds_endereco VARCHAR2(50) NOT NULL,
ds_cidade VARCHAR2(50) NOT NULL,
ds_estado VARCHAR2(50) NOT NULL,
ds_pais VARCHAR2(50) NOT NULL
);  ALTER TABLE t_localizacao ADD CONSTRAINT t_localizacao_pk PRIMARY KEY ( id_localizacao );
CREATE TABLE t_medicoes (
id_medicao VARCHAR2(10) NOT NULL,
id_producao VARCHAR2(10) NOT NULL,
id_medida VARCHAR2(10) NOT NULL,
id_tipo VARCHAR2(10) NOT NULL,
qtd_medicao NUMBER(10) NOT NULL
);
CREATE UNIQUE INDEX t_medicoes__idx ON
t_medicoes (
id_tipo
ASC );
CREATE UNIQUE INDEX t_medicoes__idxv1 ON
t_medicoes (
id_medida
ASC );
ALTER TABLE t_medicoes ADD CONSTRAINT t_medicoes_pk PRIMARY KEY ( id_medicao );
CREATE TABLE t_meta (
id_meta VARCHAR2(10) NOT NULL,
id_objetivo VARCHAR2(10) NOT NULL,
nm_meta VARCHAR2(50) NOT NULL,
ds_meta VARCHAR2(100) NOT NULL,
dt_inicio DATE NOT NULL,
dt_fim DATE NOT NULL,
vr_alvo NUMBER(10, 5) NOT NULL,
qtd_alvo NUMBER(10) NOT NULL
);
ALTER TABLE t_meta ADD CONSTRAINT t_meta_pk PRIMARY KEY ( id_meta );
CREATE TABLE t_objetivo (
id_objetivo VARCHAR2(10) NOT NULL,
id_produto VARCHAR2(10),
mm_objetivo VARCHAR2(50) NOT NULL,
ds_objetivo VARCHAR2(100) NOT NULL,
dt_inicio DATE NOT NULL,
dt_fim DATE NOT NULL
);
CREATE UNIQUE INDEX t_objetivo__idx ON
t_objetivo (
id_produto
ASC );
ALTER TABLE t_objetivo ADD CONSTRAINT t_objetivo_pk PRIMARY KEY ( id_objetivo );
CREATE TABLE t_prod_composicao (
id_insumo VARCHAR2(10) NOT NULL,
id_produto VARCHAR2(10) NOT NULL
);
ALTER TABLE t_prod_composicao ADD CONSTRAINT t_prod_composicao_pk PRIMARY KEY ( id_insumo,
id_produto ); CREATE TABLE t_producao (
id_producao VARCHAR2(10) NOT NULL,
id_produto VARCHAR2(10) NOT NULL,
id_empresa VARCHAR2(10) NOT NULL,
id_requisicao VARCHAR2(10) NOT NULL,
qtd_producao NUMBER(10) NOT NULL,
dt_producao DATE NOT NULL
);
CREATE UNIQUE INDEX t_poducao__idx ON
t_producao (
id_requisicao
ASC );
ALTER TABLE t_producao ADD CONSTRAINT t_poducao_pk PRIMARY KEY ( id_producao );
CREATE TABLE t_produto (
id_produto VARCHAR2(10) NOT NULL,
id_media VARCHAR2(10) NOT NULL,
nm_produto VARCHAR2(30) NOT NULL,
vr_unitario NUMBER(10, 5) NOT NULL,
status CHAR(1) NOT NULL
);
CREATE UNIQUE INDEX t_produto__idx ON
t_produto (
id_media
ASC );
ALTER TABLE t_produto ADD CONSTRAINT t_produto_pk PRIMARY KEY ( id_produto );
CREATE TABLE t_requisicao (
id_requisicao VARCHAR2(10) NOT NULL,
dt_requisicao DATE NOT NULL,
qtd_requisicao NUMBER(5) NOT NULL
);
ALTER TABLE t_requisicao ADD CONSTRAINT t_requisicao_pk PRIMARY KEY ( id_requisicao );
CREATE TABLE t_tipo (
id_tipo VARCHAR2(10) NOT NULL,
ds_tipo VARCHAR2(30) NOT NULL
);
ALTER TABLE t_tipo ADD CONSTRAINT t_tipo_pk PRIMARY KEY ( id_tipo );
CREATE TABLE t_unid_medida (
id_medida VARCHAR2(10) NOT NULL,
ds_medida VARCHAR2(30) NOT NULL
);
ALTER TABLE t_unid_medida ADD CONSTRAINT t_unid_medida_pk PRIMARY KEY ( id_medida );
ALTER TABLE t_producao
ADD CONSTRAINT t_empresa_fk FOREIGN KEY ( id_empresa )
REFERENCES t_empresa ( id_empresa );
ALTER TABLE t_emp_objetivo
ADD CONSTRAINT t_empresa_fkv2 FOREIGN KEY ( id_empresa )
REFERENCES t_empresa ( id_empresa ) ;  ALTER TABLE t_fornecimento
ADD CONSTRAINT t_fornecedor_fk FOREIGN KEY ( id_fornecedor )
REFERENCES t_fornecedor ( id_fornecedor );
ALTER TABLE t_certificado
ADD CONSTRAINT t_fornecedor_fkv1 FOREIGN KEY ( id_fornecedor )
REFERENCES t_fornecedor ( id_fornecedor );
ALTER TABLE t_prod_composicao
ADD CONSTRAINT t_insumos_fk FOREIGN KEY ( id_insumo )
REFERENCES t_insumos ( id_insumo );
ALTER TABLE t_fornecimento
ADD CONSTRAINT t_insumos_fkv1 FOREIGN KEY ( id_insumo )
REFERENCES t_insumos ( id_insumo );
ALTER TABLE t_empresa
ADD CONSTRAINT t_localizacao_fk FOREIGN KEY ( id_localizacao )
REFERENCES t_localizacao ( id_localizacao );
ALTER TABLE t_fornecedor
ADD CONSTRAINT t_localizacao_fkv2 FOREIGN KEY ( id_localizacao )
REFERENCES t_localizacao ( id_localizacao );
ALTER TABLE t_emp_objetivo
ADD CONSTRAINT t_objetivo_fk FOREIGN KEY ( id_objetivo )
REFERENCES t_objetivo ( id_objetivo );
ALTER TABLE t_meta
ADD CONSTRAINT t_objetivo_fkv2 FOREIGN KEY ( id_objetivo )
REFERENCES t_objetivo ( id_objetivo );
ALTER TABLE t_medicoes
ADD CONSTRAINT t_poducao_fk FOREIGN KEY ( id_producao )
REFERENCES t_producao ( id_producao );
ALTER TABLE t_producao
ADD CONSTRAINT t_produto_fk FOREIGN KEY ( id_produto )
REFERENCES t_produto ( id_produto );
ALTER TABLE t_objetivo
ADD CONSTRAINT t_produto_fkv1 FOREIGN KEY ( id_produto )
REFERENCES t_produto ( id_produto );
ALTER TABLE t_prod_composicao
ADD CONSTRAINT t_produto_fkv2 FOREIGN KEY ( id_produto )
REFERENCES t_produto ( id_produto );
ALTER TABLE t_producao
ADD CONSTRAINT t_requisicao_fk FOREIGN KEY ( id_requisicao )
REFERENCES t_requisicao ( id_requisicao );
ALTER TABLE t_insumos
ADD CONSTRAINT t_requisicao_fkv2 FOREIGN KEY ( id_requisicao )
REFERENCES t_requisicao ( id_requisicao );
ALTER TABLE t_medicoes
ADD CONSTRAINT t_tipo_fk FOREIGN KEY ( id_tipo )
REFERENCES t_tipo ( id_tipo );  ALTER TABLE t_insumos
ADD CONSTRAINT t_tipo_fkv2 FOREIGN KEY ( id_tipo )
REFERENCES t_tipo ( id_tipo );
ALTER TABLE t_medicoes
ADD CONSTRAINT t_unid_medida_fk FOREIGN KEY ( id_medida )
REFERENCES t_unid_medida ( id_medida );
ALTER TABLE t_produto
ADD CONSTRAINT t_unid_medida_fkv1 FOREIGN KEY ( id_media )
REFERENCES t_unid_medida ( id_medida );
ALTER TABLE t_fator_conver
ADD CONSTRAINT t_unid_medida_fkv2 FOREIGN KEY ( id_media )
REFERENCES t_unid_medida ( id_medida );
ALTER TABLE t_insumos
ADD CONSTRAINT t_unid_medida_fkv4 FOREIGN KEY ( id_media )
REFERENCES t_unid_medida ( id_medida );