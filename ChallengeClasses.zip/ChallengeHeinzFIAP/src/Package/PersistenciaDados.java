package Package;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class PersistenciaDados {

    public static void main(String[] args) {
        String url = "jdbc:oracle:thin:@oracle.fiap.com.br:1521:ORCL";
        String username = "OPS$RM96464";
        String password = "123456";

        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection connection = DriverManager.getConnection(url, username, password);

            inserirEmpresa(connection, "1", "1", "Empresa A");
            inserirLocalizacao(connection, "1", "Endereço A", "Cidade A", "Estado A", "Pais A");
            inserirFornecedor(connection, "1", "1", "Fornecedor A");
            inserirTipo(connection, "1", "Tipo A");
            inserirUnidadeMedida(connection, "1", "Unidade A");
            inserirProduto(connection, "1", "1", "Produto A", 10.0, "A");
            inserirRequisicao(connection, "1", "2023-05-22", 100);
            inserirObjetivo(connection, "1", "1", "Objetivo A", "Descrição do Objetivo", "2023-01-01", "2023-12-31");
            inserirComposicaoProduto(connection, "1", "1");
            inserirProducao(connection, "1", "1", "1", "1", 100, "2023-05-22");
            inserirMedicao(connection, "1", "1", "1", "1", 50);
            inserirMeta(connection, "1", "1", "Meta A", "Descrição da Meta", "2023-01-01", "2023-12-31", 100.0, 10);
            inserirCertificado(connection, "1", "1", "Certificado A", "Emissor A", "Autenticação A", "2023-01-01", "2024-01-01");
            inserirEmpObjetivo(connection, "1", "1");
            inserirFatorConversao(connection, "1", "1", 1.0, "Unidade Origem", "Unidade Destino");
            inserirFornecimento(connection, "1", "1");

            connection.close();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void inserirEmpresa(Connection connection, String idEmpresa, String idLocalizacao, String nomeEmpresa) throws SQLException {
        String query = "INSERT INTO t_empresa(id_empresa, id_localizacao, nm_empresa) VALUES (?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, idEmpresa);
            statement.setString(2, idLocalizacao);
            statement.setString(3, nomeEmpresa);
            statement.executeUpdate();
        }
    }

    private static void inserirLocalizacao(Connection connection, String idLocalizacao, String endereco, String cidade, String estado, String pais) throws SQLException {
        String query = "INSERT INTO t_localizacao(id_localizacao, ds_endereco, ds_cidade, ds_estado, ds_pais) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, idLocalizacao);
            statement.setString(2, endereco);
            statement.setString(3, cidade);
            statement.setString(4, estado);
            statement.setString(5, pais);
            statement.executeUpdate();
        }
    }

    private static void inserirFornecedor(Connection connection, String idFornecedor, String idLocalizacao, String nomeFornecedor) throws SQLException {
        String query = "INSERT INTO t_fornecedor(id_fornecedor, id_localizacao, nm_fornecedor) VALUES (?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, idFornecedor);
            statement.setString(2, idLocalizacao);
            statement.setString(3, nomeFornecedor);
            statement.executeUpdate();
        }
    }

    private static void inserirTipo(Connection connection, String idTipo, String nomeTipo) throws SQLException {
        String query = "INSERT INTO t_tipo(id_tipo, nm_tipo) VALUES (?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, idTipo);
            statement.setString(2, nomeTipo);
            statement.executeUpdate();
        }
    }

    private static void inserirUnidadeMedida(Connection connection, String idUnidade, String nomeUnidade) throws SQLException {
        String query = "INSERT INTO t_unidade_medida(id_unidade, nm_unidade) VALUES (?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, idUnidade);
            statement.setString(2, nomeUnidade);
            statement.executeUpdate();
        }
    }

    private static void inserirProduto(Connection connection, String idProduto, String idFornecedor, String nomeProduto, double valorUnitario, String idTipo) throws SQLException {
        String query = "INSERT INTO t_produto(id_produto, id_fornecedor, nm_produto, vl_unitario, id_tipo) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, idProduto);
            statement.setString(2, idFornecedor);
            statement.setString(3, nomeProduto);
            statement.setDouble(4, valorUnitario);
            statement.setString(5, idTipo);
            statement.executeUpdate();
        }
    }

    private static void inserirRequisicao(Connection connection, String idRequisicao, String dataRequisicao, int quantidade) throws SQLException {
        String query = "INSERT INTO t_requisicao(id_requisicao, dt_requisicao, qt_produto) VALUES (?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, idRequisicao);
            statement.setString(2, dataRequisicao);
            statement.setInt(3, quantidade);
            statement.executeUpdate();
        }
    }

    private static void inserirObjetivo(Connection connection, String idObjetivo, String idProduto, String nomeObjetivo, String descricao, String dataInicio, String dataFim) throws SQLException {
        String query = "INSERT INTO t_objetivo(id_objetivo, id_produto, nm_objetivo, ds_objetivo, dt_inicio, dt_fim) VALUES (?, ?, ?, ?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, idObjetivo);
            statement.setString(2, idProduto);
            statement.setString(3, nomeObjetivo);
            statement.setString(4, descricao);
            statement.setString(5, dataInicio);
            statement.setString(6, dataFim);
            statement.executeUpdate();
        }
    }

    private static void inserirComposicaoProduto(Connection connection, String idProduto, String idComponente) throws SQLException {
        String query = "INSERT INTO t_composicao_produto(id_produto, id_componente) VALUES (?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, idProduto);
            statement.setString(2, idComponente);
            statement.executeUpdate();
        }
    }

    private static void inserirProducao(Connection connection, String idProducao, String idObjetivo, String idProduto, String idRequisicao, int quantidade, String dataProducao) throws SQLException {
        String query = "INSERT INTO t_producao(id_producao, id_objetivo, id_produto, id_requisicao, qt_produzida, dt_producao) VALUES (?, ?, ?, ?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, idProducao);
            statement.setString(2, idObjetivo);
            statement.setString(3, idProduto);
            statement.setString(4, idRequisicao);
            statement.setInt(5, quantidade);
            statement.setString(6, dataProducao);
            statement.executeUpdate();
        }
    }

    private static void inserirMedicao(Connection connection, String idMedicao, String idObjetivo, String idProduto, String idRequisicao, int quantidade) throws SQLException {
        String query = "INSERT INTO t_medicao(id_medicao, id_objetivo, id_produto, id_requisicao, qt_medida) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, idMedicao);
            statement.setString(2, idObjetivo);
            statement.setString(3, idProduto);
            statement.setString(4, idRequisicao);
            statement.setInt(5, quantidade);
            statement.executeUpdate();
        }
    }

    private static void inserirMeta(Connection connection, String idMeta, String idObjetivo, String nomeMeta, String descricao, String dataInicio, String dataFim, double valorMeta, int percentual) throws SQLException {
        String query = "INSERT INTO t_meta(id_meta, id_objetivo, nm_meta, ds_meta, dt_inicio, dt_fim, vl_meta, pc_meta) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, idMeta);
            statement.setString(2, idObjetivo);
            statement.setString(3, nomeMeta);
            statement.setString(4, descricao);
            statement.setString(5, dataInicio);
            statement.setString(6, dataFim);
            statement.setDouble(7, valorMeta);
            statement.setInt(8, percentual);
            statement.executeUpdate();
        }
    }

    private static void inserirCertificado(Connection connection, String idCertificado, String idProduto, String nomeCertificado, String emissor, String autenticacao, String dataInicio, String dataFim) throws SQLException {
        String query = "INSERT INTO t_certificado(id_certificado, id_produto, nm_certificado, nm_emissor, ds_autenticacao, dt_inicio, dt_fim) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, idCertificado);
            statement.setString(2, idProduto);
            statement.setString(3, nomeCertificado);
            statement.setString(4, emissor);
            statement.setString(5, autenticacao);
            statement.setString(6, dataInicio);
            statement.setString(7, dataFim);
            statement.executeUpdate();
        }
    }

    private static void inserirEmpObjetivo(Connection connection, String idEmpresa, String idObjetivo) throws SQLException {
        String query = "INSERT INTO t_emp_objetivo(id_empresa, id_objetivo) VALUES (?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, idEmpresa);
            statement.setString(2, idObjetivo);
            statement.executeUpdate();
        }
    }

    private static void inserirFatorConversao(Connection connection, String idUnidadeOrigem, String idUnidadeDestino, double fatorConversao, String unidadeOrigem, String unidadeDestino) throws SQLException {
        String query = "INSERT INTO t_fator_conversao(id_unidade_origem, id_unidade_destino, vl_fator_conversao, nm_unidade_origem, nm_unidade_destino) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, idUnidadeOrigem);
            statement.setString(2, idUnidadeDestino);
            statement.setDouble(3, fatorConversao);
            statement.setString(4, unidadeOrigem);
            statement.setString(5, unidadeDestino);
            statement.executeUpdate();
        }
    }

    private static void inserirFornecimento(Connection connection, String idFornecedor, String idCertificado) throws SQLException {
        String query = "INSERT INTO t_fornecimento(id_fornecedor, id_certificado) VALUES (?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, idFornecedor);
            statement.setString(2, idCertificado);
            statement.executeUpdate();
        }
    }
}
