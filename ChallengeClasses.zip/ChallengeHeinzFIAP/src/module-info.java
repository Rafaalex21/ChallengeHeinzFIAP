/**
 * 
 */
/**
 * @author Rafael
 *
 */
module ChallengeHeinzFIAP {
	requires java.sql;
}